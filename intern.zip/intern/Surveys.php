<?php

/* declaration of a class called Surveys with public properties and an object constructor */
class Surveys
 {
	 
     public $id;
     public $surname;
     public $first_names;
	 public $contact_number;
	 public $s_date;
	 public $age;
	 public $pizza;
	 public $pasta;
	 public $pap;
	 public $chicken;
	 public $beef;
	 public $other;
	 public $g_out;
	 public $movies;
	 public $tv;
	 public $radio;


     public function _construct()
     {
         

     }


   
 }



?>