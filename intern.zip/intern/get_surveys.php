<?php


// include the code from a file called Surveys.php
 require_once('Surveys.php');

 // include the code from a file called database_credentials.php
 require_once('database_credentials.php');
 
 // connect to a MySQL dataabse using the values from the database_credentials.php file
 $conn = new mysqli($db_servername,$db_username,$db_password,$db_name);

 // make for the file is requested using HTTP POST
if($_SERVER["REQUEST_METHOD"] == "POST"){
	

	
					if($conn->connect_error){
						
						// if connecting to the database failed display this error message and stop execution of the code
						die ("Connection failed : ".$conn->connect_error);
	
	
					}else {
							
							// declare a surveys array to store the results from the MySQL SELECT query
							$surveys = array();
							
							// declare and run the MySQL SELECT query
							$sql = "SELECT * FROM survey";
							$result = $conn->query($sql);
	     
					       $array_count_num = 0;

					if ($result && $result->num_rows && $result->num_rows > 0){
									
						
						
						 while ($row = $result->fetch_assoc()){
							
							/* if there are results from the MySQL SELECT query store each row as an object called Surveys into the surveys array we declared ealier */	
							
							$surveys[$array_count_num] = new Surveys();
							$surveys[$array_count_num]->surname = $row["surname"];
							$surveys[$array_count_num]->id = $row["id"];
							$surveys[$array_count_num]->first_names = $row["first_names"];
							$surveys[$array_count_num]->contact_number = $row["contact_number"];
							$surveys[$array_count_num]->s_date = $row["s_date"];
							$surveys[$array_count_num]->age = $row["age"];

							$surveys[$array_count_num]->pizza = $row["pizza"];
							$surveys[$array_count_num]->pasta = $row["pasta"];
							$surveys[$array_count_num]->pap = $row["pap"];
							$surveys[$array_count_num]->chicken = $row["chicken"];
							$surveys[$array_count_num]->beef = $row["beef"];
							$surveys[$array_count_num]->other = $row["other"];

							$surveys[$array_count_num]->g_out = $row["g_out"];
							$surveys[$array_count_num]->movies = $row["movies"];
							$surveys[$array_count_num]->tv = $row["tv"];
							$surveys[$array_count_num]->radio = $row["radio"];

							
							$array_count_num++;
						}
						
						
						// send the objects back to the requesting file as a JSON object
						echo json_encode($surveys); 
						
					
						
					}else {
						
						
						/* if the MySQL SELECT query did not bring back results send back this text to the requesting file */
						echo "Could not get surveys.";
						
						
						
						
					}
					
		  }
					
		

	
	
} 






?>