<?php

  /*   $db_servername = "host36";
		$db_username = "ekbukzbf_intern";
		$db_password = "Tk?S0*d0*SId";
		$db_name = "ekbukzbf_intern";   */ 

		
		 
	     /* These are database credentials for running localhost. Comment the folowing code and uncomment the one above and put your mysql database credentials */
		$db_servername = "localhost";
		$db_username = "root";
		$db_password = "";
		$db_name = "intern"; 



?>