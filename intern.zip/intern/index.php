<?php



?>
<html>
<head>
  <title>Survey</title>
  <style>
  .container {
    height: 200px;
    position: relative;

  }

  .center {
    margin: 0;
    position: absolute;
    top: 50%;
    left: 50%;
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
  }

  a:link {
  text-decoration: none;
}

a:visited {
  text-decoration: none;
}

a:hover {
  text-decoration: none;
}

a:active {
  text-decoration: none;
}
</style>
</head>
<body style="background-image: url('nice.jpg');">
<div class='container'>
   <div class='center'>
  <button id = 'fill' style="width:250px;height:50px;"><a href='fill.php'>Fill out survey</a></button><br /><br />
  <button id = 'view' style="width:250px;height:50px;"><a href='view.php'>View survey results</a></button>
</div>
</div>
</body>
</html>
