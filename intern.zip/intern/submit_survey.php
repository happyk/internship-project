<?php



require_once('database_credentials.php');
 
 $conn = new mysqli($db_servername,$db_username,$db_password,$db_name);
    
if($_SERVER["REQUEST_METHOD"] == "POST"){
	

	
					if($conn->connect_error){
	
						die ("Connection failed : ".$conn->connect_error);
	
	
					}else {


					// get the values sent from the AJAX request and set it to PHP variables
					$surname = $_POST['surname'];
					$first_names = $_POST['first_names'];
					$contact_number = $_POST['contact_number'];
					$s_date = $_POST['s_date'];
					$age = (int) $_POST['age'];

					$pizza = $_POST['pizza'];
					$pasta = $_POST['pasta'];
					$pap = $_POST['pap'];
					$chicken = $_POST['chicken'];
					$beef = $_POST['beef'];
					$other = $_POST['other'];

					$out = (int) $_POST['out'];
					$movies = (int) $_POST['movies'];
					$tv = (int) $_POST['tv'];
					$radio = (int) $_POST['radio'];

					// get the person year of birth
					/*
					$p_year = (int) explode('/', $s_date)[2];

					// get the current year
					$c_year = (int) date('Y');

					// calculate the age
					$age = $c_year - $p_year;
				    
				    */



 					$sql = "INSERT INTO survey (surname, first_names, contact_number, s_date, pizza, pasta, pap, chicken, beef, other, g_out, movies, tv, radio, age ) VALUES ('".$surname."', '".$first_names."','".$contact_number."','".$s_date."', '".$pizza."', '".$pasta."', '".$pap."', '".$chicken."', '".$beef."', '".$other."', ".$out.", ".$movies.", ".$tv.", ".$radio.", ".$age.")";
					    
						
						if($conn->query($sql) === TRUE){
							
							echo "Survey submitted succesfully ";
							
						}else{
							
							echo "Could not submit survey ".mysqli_error($conn);
							
						}




			}


}





?>