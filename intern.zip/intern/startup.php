<?php

// get database credentials and connect to the mysql database
				require_once('database_credentials.php');
				$conn = new mysqli($db_servername,$db_username,$db_password,$db_name);
				
				
				
				
				if($conn->connect_error){
	
							die ("Connection failed : ".$conn->connect_error);
	
	
					}else {
						
						// This needs to be changed to your database name created locally or on your hosted mysql database
						$sql = "CREATE DATABASE intern";
					    $result = $conn->query($sql);
						
						if($result){
							
							// if database intern created
							echo "<br /><br />Database intern has been created<br /><br />";
							
						}else{
							
						    // if database intern not created and display an error message
							echo "Could not create intern Database<br /><br />".mysqli_error($conn)."<br />";
							
						}



						// creating a survey table	
						$sql = "CREATE TABLE survey (id INT(30) UNSIGNED AUTO_INCREMENT PRIMARY KEY, surname VARCHAR(255) NOT NULL, first_names VARCHAR(255) NOT NULL, contact_number VARCHAR(255) NOT NULL, s_date VARCHAR(255) NOT NULL, age INT(30) UNSIGNED NOT NULL  , pizza VARCHAR(255), pasta VARCHAR(255), pap VARCHAR(255), chicken VARCHAR(255), beef VARCHAR(255), other VARCHAR(255), g_out INT(30) UNSIGNED, movies INT(30) UNSIGNED, tv INT(30) UNSIGNED, radio INT(30) UNSIGNED)";
					    $result = $conn->query($sql);
						
						if($result){
							
							// if table survey created
							echo "<br /><br />Table survey created<br /><br />";
							
						}else{
							
							// if table survey not created and display an error
							echo "Could not create survey table<br /><br />".mysqli_error($conn)."<br />";
							
						}







			}


?>