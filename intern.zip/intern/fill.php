<?php


?>
<html>
<head>
  <title>Survey</title>
  <style>
  .container {
    height: 200px;
    position: relative;

  }

  .center {
    margin: 0;
    position: absolute;
    top: 50%;
    left: 50%;
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
  }

  a:link {
  text-decoration: none;
}

a:visited {
  text-decoration: none;
}

a:hover {
  text-decoration: none;
}

a:active {
  text-decoration: none;
}
</style>
</head>
<body style="background-image: url('nice.jpg');">
<h1>Take our Survey</h1>
<h2>Personal Details</h2>
<div style="padding-left:50px;">
<table>
<tr><td>Surname </td><td></td><td><input type="text" id = 'surname' name = 'surname' placeholder="Surname" value="" /></td></tr>
<tr><td><br /></td></tr>
<tr><td>First Names </td><td></td><td><input type="text" id = 'f_names' name = 'f_names' placeholder="First Names" value="" /></td></tr>
<tr><td><br /></td></tr>
<tr><td>Contact Number </td><td></td><td><input type="tel" id = 'contact_number' name = 'contact_number' placeholder="Contact Number" value="" /></td></tr>
<tr><td><br /></td></tr>
<tr><td>Date </td><td></td><td><input type="date" id = 'c_date' name = 'c_date' placeholder="Date" value="" /></td></tr>
<tr><td><br /></td></tr>
<tr><td>Age </td><td></td><td><input type='number' id = 'age' name = 'age' placeholder="Age" value="" /></td></tr>
</table>
</div>
<br />
<p>What is your favourite food? (You can choose more than 1 answer)</p>
<input type="checkbox" id="pizza" name="food" value="Pizza"><span></span>
<label for="pizza">Pizza</label><br />
<input type="checkbox" id="pasta" name="food" value="Pasta">
<label for="pasta">Pasta</label><br />
<input type="checkbox" id="pap" name="food" value="Pap">
<label for="pizza">Pap and Wors</label><br />
<input type="checkbox" id="chicken" name="food" value="Chicken">
<label for="pizza">Chicken stir fry</label><br />
<input type="checkbox" id="beef" name="food" value="Beef">
<label for="pizza">Beef stir fry</label><br />
<input type="checkbox" id="other" name="food" value="Other">
<label for="pizza">Other</label><br />
<br />
<br />
<p>On a scale of 1 to 5 indicate whether you strongly agree to strongly disagree</p>
<table>
<tr>
	<td style="background-color:grey;width:250px;text-align:center;"></td>
	<td style="background-color:grey;width:250px;text-align:center;">Strongly agree<br />(1)</td>
	<td style="background-color:grey;width:250px;text-align:center;">Agree<br/>
(2)</td>
    <td style="background-color:grey;width:250px;text-align:center;">Neutral<br />
(3)</td>
    <td style="background-color:grey;width:250px;text-align:center;">Disagree<br />
(4)</td>
    <td style="background-color:grey;width:250px;text-align:center;">Strongly disagree<br />
(5)</td>
</tr>
<tr>
	<td style="width:250px;text-align:center;">I like to eat out</td>
    <td style="width:250px;text-align:center;"><input type="radio" id="out_1" name="out" value="1" /></td>
    <td style="width:250px;text-align:center;"><input type="radio" id="out_2" name="out" value="2" /></td>
    <td style="width:250px;text-align:center;"><input type="radio" id="out_3" name="out" value="3" /></td>
    <td style="width:250px;text-align:center;"><input type="radio" id="out_4" name="out" value="4" /></td>
    <td style="width:250px;text-align:center;"><input type="radio" id="out_5" name="out" value="5" /></td>
</tr>
<tr>
	<td style="width:250px;text-align:center;">I like to watch movies</td>
    <td style="width:250px;text-align:center;"><input type="radio" id="movies_1" name="movies" value="1" /></td>
    <td style="width:250px;text-align:center;"><input type="radio" id="movies_2" name="movies" value="2" /></td>
    <td style="width:250px;text-align:center;"><input type="radio" id="movies_3" name="movies" value="3" /></td>
    <td style="width:250px;text-align:center;"><input type="radio" id="movies_4" name="movies" value="4" /></td>
    <td style="width:250px;text-align:center;"><input type="radio" id="movies_5" name="movies" value="5" /></td>
</tr>
<tr>
	<td style="width:250px;text-align:center;">I like to watch TV</td>
	<td style="width:250px;text-align:center;"><input type="radio" id="tv_1" name="tv" value="1" /></td>
	<td style="width:250px;text-align:center;"><input type="radio" id="tv_2" name="tv" value="2" /></td>
	<td style="width:250px;text-align:center;"><input type="radio" id="tv_3" name="tv" value="3" /></td>
	<td style="width:250px;text-align:center;"><input type="radio" id="tv_4" name="tv" value="4" /></td>
	<td style="width:250px;text-align:center;"><input type="radio" id="tv_5" name="tv" value="5" /></td>
</tr>
<tr>
	<td style="width:250px;text-align:center;">I like to listen to the radio</td>
    <td style="width:250px;text-align:center;"><input type="radio" id="radio_1" name="radio" value="1" /></td>
    <td style="width:250px;text-align:center;"><input type="radio" id="radio_2" name="radio" value="2" /></td>
    <td style="width:250px;text-align:center;"><input type="radio" id="radio_3" name="radio" value="3" /></td>
    <td style="width:250px;text-align:center;"><input type="radio" id="radio_4" name="radio" value="4" /></td>
    <td style="width:250px;text-align:center;"><input type="radio" id="radio_5" name="radio" value="5" /></td>
</tr>
<tr></tr>
</table>
<br />
<div class='container'>
   <div class='center'>
  <button id = 'submit' style="width:250px;height:50px;">Submit</button>
</div>
</div>
<!-- including JQuery -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">

	// declare variables correspomding to the inputs 
	var $surname = '';
	var $first_names = '';
	var $contact_number = '';
	var $s_date = '';
	var $age = '';

	var $pizza = 0;
	var $pasta = 0;
	var $pap = 0;
	var $chicken = 0;
	var $beef = 0;
	var $other = 0;
	var $out = '';
	var $movies = '';
	var $tv = '';
	var $radio = '';

	var $out = '';
	var $movies = '';
	var $tv = '';
	var $radio = '';

 	// listening for when the pizza checkbox has been checked or unchecked 
	$('#pizza').change(function(){

		if($pizza == 0){
			// if it was not checked set the $pizza variable to 1 meaning it is now checked
			$pizza = 1;

		}else{
			// if the $pizza variable is 1 it means it was checked now set it to mean it is unchecked
			$pizza = 0;

		}


	});


	// listening for when the pasta checkbox has been checked or unchecked 
	$('#pasta').change(function(){

		if($pasta == 0){
			// if it was not checked set the $pasta variable to 1 meaning it is now checked
			$pasta = 1;

		}else{
			// if the $pasta variable is 1 it means it was checked now set it to mean it is unchecked
			$pasta = 0;

		}


	});


	// listening for when the pap checkbox has been checked or unchecked 
	$('#pap').change(function(){

		if($pap == 0){
			// if it was not checked set the $pap variable to 1 meaning it is now checked
			$pap = 1;

		}else{
			// if the $pap variable is 1 it means it was checked now set it to mean it is unchecked
			$pap = 0;

		}


	});


	// listening for when the chicken checkbox has been checked or unchecked 
	$('#chicken').change(function(){

		if($chicken == 0){
			// if it was not checked set the $chicken variable to 1 meaning it is now checked
			$chicken = 1;

		}else{
			// if the $chicken variable is 1 it means it was checked now set it to mean it is unchecked
			$chicken = 0;

		}


	});


	// listening for when the beef checkbox has been checked or unchecked 
	$('#beef').change(function(){

		if($beef == 0){
			// if it was not checked set the $beef variable to 1 meaning it is now checked
			$beef = 1;

		}else{
			// if the $beef variable is 1 it means it was checked now set it to mean it is unchecked
			$beef = 0;

		}


	});


	// listening for when the other checkbox has been checked or unchecked 
	$('#other').change(function(){

		if($other == 0){
			// if it was not other set the $pizza variable to 1 meaning it is now checked
			$other = 1;

		}else{
			// if the $other variable is 1 it means it was checked now set it to mean it is unchecked
			$other = 0;

		}


	});

     // listening for change event on the question 'I like to eat out'
	 $('input[name="out"]').change(function(){

	 	// save on the $out variable the selected value 
	 	$out = $(this).val();


	 });


	  // listening for change event on the question 'I like to watch movies'
	 $('input[name="movies"]').change(function(){

	 	// save on the $movies variable the selected value 
	 	$movies = $(this).val();


	 });


	   // listening for change event on the question 'I like to watch TV'
	 $('input[name="tv"]').change(function(){

	 	// save on the $tv variable the selected value 
	 	$tv = $(this).val();


	 });


	    // listening for change event on the question 'I like to listen to the radio'
	 $('input[name="radio"]').change(function(){

	 	// save on the $radio variable the selected value 
	 	$radio = $(this).val();


	 });


    // listening for a click event on the button with an id submit using JQuery and run the anonymous function when a user has clicked the button
	$('#submit').click(function(){

	 $surname = $('#surname').val();
	 $first_names = $('#f_names').val();
	 $contact_number = $('#contact_number').val();
	 $s_date = $('#c_date').val();
	 $age = $('#age').val();

	 // if any of the text inputs are empty display an error message and stop execution of further code in this function
	 if($surname.trim() == '' || $first_names.trim() == '' || $contact_number.trim() == '' || $s_date.trim() == '' || $age.trim() == ''){

	 	alert('Some information is missing on the Personal Details part. Please fill in the form in full.');
	 	return;

	 }


	 if($pizza == 0 && $pasta == 0 && $pap == 0 && $chicken == 0 && $beef == 0 && $other == 0){

	 	// if not even 1 value is checked on the favourite food section diplay an error and stop execution of the submit button
	 	alert('Please select atleast 1 value on favourite food section.');
	 	return;


	 }


	 if($out.trim() == '' || $movies.trim() == '' || $tv.trim() == '' || $radio.trim() == ''){

	 	alert('Please scale every activity on the scalling section');
	 	return;

	 }


	 // sending the information to the 'submit_survey.php' page as an AJAX request
	 $.post('submit_survey.php',{
	 	surname : $surname,
	 	first_names : $first_names,
	 	contact_number : $contact_number,
	 	s_date : $s_date,
	 	age : $age,
	 	pizza : $pizza,
	 	pasta : $pasta,
	 	pap : $pap,
	 	chicken : $chicken,
	 	beef : $beef,
	 	other : $other,
	 	out : $out,
	 	movies : $movies,
	 	tv : $tv,
	 	radio : $radio
	 },function(data,status){

	 		alert(data);

	 });




	});

</script>
</body>
</html>
