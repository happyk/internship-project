<?php



?>
<html>
<head>
	<title>Survey</title>
<style>
  .container {
    height: 200px;
    position: relative;

  }

  .center {
    margin: 0;
    position: absolute;
    top: 50%;
    left: 50%;
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
  }

  a:link {
  text-decoration: none;
}

a:visited {
  text-decoration: none;
}

a:hover {
  text-decoration: none;
}

a:active {
  text-decoration: none;
}
</style>
</head>
<body style="background-image: url('nice.jpg');">
	<table style="padding-left: 50px;">
		<tr><td style="width:300px;">Total number of surveys:</td><td style="width:250px;" id = 'total_surveys'>#surveys</td></tr>
		<tr><td style="width:300px;">Average age:</td><td style="width:250px;" id = 'average_age'>#average age</td></tr>
		<tr><td style="width:300px;">Oldest person who participated in survey</td><td style="width:250px;" id = 'oldest_person'>#max age</td></tr>
		<tr><td style="width:300px;">Youngest person who participated in survey</td><td style="width:250px;" id = 'youngest_person'>#min age</td></tr>
	</table>
	<br />
	<table style="padding-left: 50px;">
		<tr><td style="width:300px;">Percentage of people who like Pizza:</td><td style="width:250px;" id = 'percentage_pizza'>#pizza</td></tr>
		<tr><td style="width:300px;">Percentage of people who like Pasta:</td><td style="width:250px;" id = 'percentage_pasta'>#pasta</td></tr>
		<tr><td style="width:300px;">Percentage of people who like Pap and Wors:</td><td style="width:250px;" id = 'percentage_pap'>#pap & wors</td></tr>
	</table>
	<br />
	<table style="padding-left: 50px;">
		<tr><td style="width:300px;">People like to eat out:</td><td style="width:250px;" id = 'average_out'>#average of rating</td></tr>
		<tr><td style="width:300px;">People like to watch movies:</td><td style="width:250px;" id = 'average_movies'>#average of rating</td></tr>
		<tr><td style="width:300px;">People like to watch TV:</td><td style="width:250px;" id = 'average_tv'>#average of rating</td></tr>
		<tr><td style="width:300px;">People like to listen to the radio:</td><td style="width:250px;" id = 'average_radio'>#average of rating</td></tr>
	</table>
	<div class='container'>
   <div class='center'>
  <button id = 'fill' style="width:250px;height:50px;"><a href='index.php'>OK</a></button>
</div>
</div>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">
	
	$.post('get_surveys.php',{
		p_request : 'get surveys'
	},function(data,status){

		console.log(data);
		if(data != 'Could not get surveys.'){


			data = JSON.parse(data);

			var total_surveys = data.length;
			var oldest_person = 0;
			var youngest_person = 1000;

			var total_pizza_lover = 0;
			var total_pasta_lover = 0;
			var total_pap_lover = 0;
			var total_chicken_lover = 0;
			var total_beef_lover = 0;
			var total_other_lover = 0;
			var total_favourite = 0;

			var total_out_rating = 0;
			var total_movies_rating = 0;
			var total_tv_rating = 0;
			var total_radio_rating = 0;

			$('#total_surveys').html(total_surveys);

			// get and display average age
			var age_total = 0;
			for(var i = 0; i < data.length; i++){

				// get a total of all the ages
				age_total += data[i].age; 

				// calculate the oldest person
				if(data[i].age > oldest_person){

					oldest_person = data[i].age;
				}


				// calculate the youngest person
				if(data[i].age < youngest_person){

					youngest_person = data[i].age;

				}

				// get total pizza lover
				if(data[i].pizza == 1){

					total_pizza_lover++;

				}

				// get total pasta lover
				if(data[i].pasta == 1){

					total_pasta_lover++;

				}

				// get total pap lover
				if(data[i].pap == 1){

					total_pap_lover++;

				}

				// get total chicken lover
				if(data[i].chicken == 1){

					total_chicken_lover++;


				}

				// get total beef lover
				if(data[i].beef == 1){

					total_beef_lover++;
				}

				// get total other lover
				if(data[i].other == 1){

					total_other_lover++;

				}


				// calculate total rating for eating out
				total_out_rating += data[i].g_out;

				// calcualte total rating for watching movies
				total_movies_rating += data[i].movies;

				// calculate total rating for watching tv
				total_tv_rating += data[i].tv;

				// calculate total rating for listening to radio
				total_radio_rating += data[i].radio;


			}

			// display average age
			$('#average_age').html(age_total / total_surveys);

			// display oldest person
			$('#oldest_person').html(oldest_person);

			// display youngest person
			$('#youngest_person').html(youngest_person);

			// calculate and display percentage data
			total_favourite = total_pizza_lover + total_pasta_lover + total_pap_lover + total_chicken_lover + total_beef_lover + total_other_lover;
			$('#percentage_pizza').html(((total_pizza_lover / total_favourite) * 100)+'%');
			$('#percentage_pasta').html(((total_pasta_lover / total_favourite) * 100)+'%');
			$('#percentage_pap').html(((total_pap_lover / total_favourite) * 100)+'%');


			// calculate and display average for eating out
			$('#average_out').html(total_out_rating / total_surveys);

			// calculate and display average for watching movies
			$('#average_movies').html(total_movies_rating / total_surveys);

			// calculate and display average for watching tv
			$('#average_tv').html(total_tv_rating / total_surveys);

			// calculate and display average for listening to the radio
			$('#average_radio').html(total_radio_rating / total_surveys);



		}


	});


</script>
</body>
</html>
